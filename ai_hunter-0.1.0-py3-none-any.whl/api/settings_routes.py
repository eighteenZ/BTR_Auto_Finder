"""Settings API routes for reading and writing the user .env configuration."""

from __future__ import annotations

import asyncio
import os as _os
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status

from api.security import require_admin
from pydantic import BaseModel

from config.settings import get_settings
from config.settings_store import is_configured, read_settings, update_settings
from automation.notifier import send_feishu_text
from emailing.imap_client import test_imap_connection
from emailing.smtp_client import test_smtp_connection

router = APIRouter(prefix="/api/settings", tags=["settings"], dependencies=[Depends(require_admin)])


class SettingsPayload(BaseModel):
    llm_model: str = ""
    reasoning_model: str = ""
    email_llm_model: str = ""
    email_reasoning_model: str = ""
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    openrouter_api_key: str = ""
    groq_api_key: str = ""
    zai_api_key: str = ""
    moonshot_api_key: str = ""
    minimax_api_key: str = ""
    email_openai_api_key: str = ""
    email_anthropic_api_key: str = ""
    email_openrouter_api_key: str = ""
    email_groq_api_key: str = ""
    email_zai_api_key: str = ""
    email_moonshot_api_key: str = ""
    email_minimax_api_key: str = ""
    serper_api_key: str = ""
    tavily_api_key: str = ""
    jina_api_key: str = ""
    email_provider_type: str = ""
    email_from_name: str = ""
    email_from_address: str = ""
    email_reply_to: str = ""
    email_smtp_host: str = ""
    email_smtp_port: str = ""
    email_smtp_username: str = ""
    email_smtp_password: str = ""
    email_smtp_last_test_at: str = ""
    email_imap_host: str = ""
    email_imap_port: str = ""
    email_imap_username: str = ""
    email_imap_password: str = ""
    email_imap_last_test_at: str = ""
    email_use_tls: str = ""
    email_sequence_enabled: str = ""
    email_auto_send_enabled: str = ""
    email_step1_delay_days: str = ""
    email_step2_delay_days: str = ""
    email_step3_delay_days: str = ""
    email_business_hours_start: str = ""
    email_business_hours_end: str = ""
    email_weekdays_only: str = ""
    email_timezone: str = ""
    email_daily_send_limit: str = ""
    email_hourly_send_limit: str = ""
    email_language_mode: str = ""
    email_default_language: str = ""
    email_fallback_language: str = ""
    email_tone: str = ""
    email_signature_block: str = ""
    email_signature_name: str = ""
    email_signature_title: str = ""
    email_signature_phone: str = ""
    email_signature_email: str = ""
    email_signature_company: str = ""
    email_llm_requests_per_minute: str = ""
    email_reasoning_requests_per_minute: str = ""
    email_min_fit_score_to_send: str = ""
    email_min_contactability_score_to_send: str = ""
    email_allow_inferred_target: str = ""
    email_allow_generic_company_email: str = ""
    email_require_approval_before_send: str = ""
    email_reply_detection_enabled: str = ""
    email_reply_check_interval_seconds: str = ""
    email_template_max_send_count: str = ""
    email_template_underperforming_min_assigned: str = ""
    email_template_underperforming_min_reply_rate: str = ""
    automation_feishu_webhook_url: str = ""
    automation_summary_enabled: str = ""
    automation_summary_interval_seconds: str = ""
    automation_alerts_enabled: str = ""
    automation_alert_interval_seconds: str = ""
    automation_alert_backlog_threshold: str = ""
    automation_alert_failed_messages_threshold: str = ""
    search_concurrency: str = ""
    scrape_concurrency: str = ""


class SettingsResponse(BaseModel):
    settings: dict[str, str]
    is_configured: bool


def _ensure_settings_api_enabled() -> None:
    if get_settings().settings_api_enabled:
        return
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Settings API is disabled")


class SmtpTestResponse(BaseModel):
    status: str
    message: str
    host: str
    username: str


class ImapTestResponse(BaseModel):
    status: str
    message: str
    host: str
    username: str


class FeishuTestResponse(BaseModel):
    status: str
    message: str
    webhook_url: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Settings routes ───────────────────────────────────────────────────────────
@router.get("", response_model=SettingsResponse)
async def get_settings_api():
    """Return current settings with sensitive values partially masked."""
    _ensure_settings_api_enabled()
    raw = read_settings()
    masked = {key: _mask(value) for key, value in raw.items()}
    return SettingsResponse(
        settings=masked,
        is_configured=is_configured(),
    )


@router.post("", status_code=status.HTTP_204_NO_CONTENT)
async def save_settings(payload: SettingsPayload):
    """Save settings to the user's .env file. Empty strings are skipped."""
    _ensure_settings_api_enabled()
    provided_fields = payload.model_dump(exclude_unset=True)
    field_map = {
        "llm_model": "LLM_MODEL",
        "reasoning_model": "REASONING_MODEL",
        "email_llm_model": "EMAIL_LLM_MODEL",
        "email_reasoning_model": "EMAIL_REASONING_MODEL",
        "openai_api_key": "OPENAI_API_KEY",
        "anthropic_api_key": "ANTHROPIC_API_KEY",
        "openrouter_api_key": "OPENROUTER_API_KEY",
        "groq_api_key": "GROQ_API_KEY",
        "zai_api_key": "ZAI_API_KEY",
        "moonshot_api_key": "MOONSHOT_API_KEY",
        "minimax_api_key": "MINIMAX_API_KEY",
        "email_openai_api_key": "EMAIL_OPENAI_API_KEY",
        "email_anthropic_api_key": "EMAIL_ANTHROPIC_API_KEY",
        "email_openrouter_api_key": "EMAIL_OPENROUTER_API_KEY",
        "email_groq_api_key": "EMAIL_GROQ_API_KEY",
        "email_zai_api_key": "EMAIL_ZAI_API_KEY",
        "email_moonshot_api_key": "EMAIL_MOONSHOT_API_KEY",
        "email_minimax_api_key": "EMAIL_MINIMAX_API_KEY",
        "serper_api_key": "SERPER_API_KEY",
        "tavily_api_key": "TAVILY_API_KEY",
        "jina_api_key": "JINA_API_KEY",
        "email_provider_type": "EMAIL_PROVIDER_TYPE",
        "email_from_name": "EMAIL_FROM_NAME",
        "email_from_address": "EMAIL_FROM_ADDRESS",
        "email_reply_to": "EMAIL_REPLY_TO",
        "email_smtp_host": "EMAIL_SMTP_HOST",
        "email_smtp_port": "EMAIL_SMTP_PORT",
        "email_smtp_username": "EMAIL_SMTP_USERNAME",
        "email_smtp_password": "EMAIL_SMTP_PASSWORD",
        "email_smtp_last_test_at": "EMAIL_SMTP_LAST_TEST_AT",
        "email_imap_host": "EMAIL_IMAP_HOST",
        "email_imap_port": "EMAIL_IMAP_PORT",
        "email_imap_username": "EMAIL_IMAP_USERNAME",
        "email_imap_password": "EMAIL_IMAP_PASSWORD",
        "email_imap_last_test_at": "EMAIL_IMAP_LAST_TEST_AT",
        "email_use_tls": "EMAIL_USE_TLS",
        "email_sequence_enabled": "EMAIL_SEQUENCE_ENABLED",
        "email_auto_send_enabled": "EMAIL_AUTO_SEND_ENABLED",
        "email_step1_delay_days": "EMAIL_STEP1_DELAY_DAYS",
        "email_step2_delay_days": "EMAIL_STEP2_DELAY_DAYS",
        "email_step3_delay_days": "EMAIL_STEP3_DELAY_DAYS",
        "email_business_hours_start": "EMAIL_BUSINESS_HOURS_START",
        "email_business_hours_end": "EMAIL_BUSINESS_HOURS_END",
        "email_weekdays_only": "EMAIL_WEEKDAYS_ONLY",
        "email_timezone": "EMAIL_TIMEZONE",
        "email_daily_send_limit": "EMAIL_DAILY_SEND_LIMIT",
        "email_hourly_send_limit": "EMAIL_HOURLY_SEND_LIMIT",
        "email_language_mode": "EMAIL_LANGUAGE_MODE",
        "email_default_language": "EMAIL_DEFAULT_LANGUAGE",
        "email_fallback_language": "EMAIL_FALLBACK_LANGUAGE",
        "email_tone": "EMAIL_TONE",
        "email_signature_block": "EMAIL_SIGNATURE_BLOCK",
        "email_signature_name": "EMAIL_SIGNATURE_NAME",
        "email_signature_title": "EMAIL_SIGNATURE_TITLE",
        "email_signature_phone": "EMAIL_SIGNATURE_PHONE",
        "email_signature_email": "EMAIL_SIGNATURE_EMAIL",
        "email_signature_company": "EMAIL_SIGNATURE_COMPANY",
        "email_llm_requests_per_minute": "EMAIL_LLM_REQUESTS_PER_MINUTE",
        "email_reasoning_requests_per_minute": "EMAIL_REASONING_REQUESTS_PER_MINUTE",
        "email_min_fit_score_to_send": "EMAIL_MIN_FIT_SCORE_TO_SEND",
        "email_min_contactability_score_to_send": "EMAIL_MIN_CONTACTABILITY_SCORE_TO_SEND",
        "email_allow_inferred_target": "EMAIL_ALLOW_INFERRED_TARGET",
        "email_allow_generic_company_email": "EMAIL_ALLOW_GENERIC_COMPANY_EMAIL",
        "email_require_approval_before_send": "EMAIL_REQUIRE_APPROVAL_BEFORE_SEND",
        "email_reply_detection_enabled": "EMAIL_REPLY_DETECTION_ENABLED",
        "email_reply_check_interval_seconds": "EMAIL_REPLY_CHECK_INTERVAL_SECONDS",
        "email_template_max_send_count": "EMAIL_TEMPLATE_MAX_SEND_COUNT",
        "email_template_underperforming_min_assigned": "EMAIL_TEMPLATE_UNDERPERFORMING_MIN_ASSIGNED",
        "email_template_underperforming_min_reply_rate": "EMAIL_TEMPLATE_UNDERPERFORMING_MIN_REPLY_RATE",
        "automation_feishu_webhook_url": "AUTOMATION_FEISHU_WEBHOOK_URL",
        "automation_summary_enabled": "AUTOMATION_SUMMARY_ENABLED",
        "automation_summary_interval_seconds": "AUTOMATION_SUMMARY_INTERVAL_SECONDS",
        "automation_alerts_enabled": "AUTOMATION_ALERTS_ENABLED",
        "automation_alert_interval_seconds": "AUTOMATION_ALERT_INTERVAL_SECONDS",
        "automation_alert_backlog_threshold": "AUTOMATION_ALERT_BACKLOG_THRESHOLD",
        "automation_alert_failed_messages_threshold": "AUTOMATION_ALERT_FAILED_MESSAGES_THRESHOLD",
        "search_concurrency": "SEARCH_CONCURRENCY",
        "scrape_concurrency": "SCRAPE_CONCURRENCY",
    }

    updates: dict[str, str] = {}
    smtp_fields_changed = False
    imap_fields_changed = False
    for field, env_key in field_map.items():
        if field not in provided_fields:
            continue
        value = provided_fields[field]
        if isinstance(value, str) and _is_masked(value):
            continue
        updates[env_key] = str(value)
        if field in {"email_from_address", "email_smtp_host", "email_smtp_port", "email_smtp_username", "email_smtp_password", "email_use_tls"}:
            smtp_fields_changed = True
        if field in {"email_imap_host", "email_imap_port", "email_imap_username", "email_imap_password"}:
            imap_fields_changed = True

    if smtp_fields_changed:
        updates["EMAIL_SMTP_LAST_TEST_AT"] = ""
    if imap_fields_changed:
        updates["EMAIL_IMAP_LAST_TEST_AT"] = ""

    if updates:
        update_settings(updates)
        for env_key, value in updates.items():
            _os.environ[env_key] = value

    get_settings.cache_clear()


@router.post("/email/test", response_model=SmtpTestResponse)
async def test_email_settings():
    """Test SMTP connectivity using the current saved settings."""
    get_settings.cache_clear()
    settings = get_settings()
    try:
        result = await asyncio.to_thread(test_smtp_connection, settings)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    tested_at = _now_iso()
    update_settings({"EMAIL_SMTP_LAST_TEST_AT": tested_at})
    _os.environ["EMAIL_SMTP_LAST_TEST_AT"] = tested_at
    get_settings.cache_clear()
    return SmtpTestResponse(
        status="ok",
        message="SMTP connection successful",
        host=result["host"],
        username=result["username"],
    )


@router.post("/email/imap-test", response_model=ImapTestResponse)
async def test_email_imap_settings():
    """Test IMAP connectivity using the current saved settings."""
    get_settings.cache_clear()
    settings = get_settings()
    try:
        result = await asyncio.to_thread(test_imap_connection, settings)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    tested_at = _now_iso()
    update_settings({"EMAIL_IMAP_LAST_TEST_AT": tested_at})
    _os.environ["EMAIL_IMAP_LAST_TEST_AT"] = tested_at
    get_settings.cache_clear()
    return ImapTestResponse(
        status="ok",
        message="IMAP connection successful",
        host=result["host"],
        username=result["username"],
    )


@router.post("/automation/feishu-test", response_model=FeishuTestResponse)
async def test_automation_feishu_webhook():
    """Send a test message to the configured Feishu webhook."""
    get_settings.cache_clear()
    settings = get_settings()
    webhook_url = str(settings.automation_feishu_webhook_url or "").strip()
    if not webhook_url:
        raise HTTPException(status_code=400, detail="Missing Feishu webhook URL in Settings")
    try:
        await asyncio.to_thread(
            send_feishu_text,
            webhook_url,
            "\n".join(
                [
                    "AI Hunter 飞书测试",
                    "这是一条测试消息。",
                    "如果你能看到这条消息，说明自动化通知 webhook 已生效。",
                ]
            ),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return FeishuTestResponse(
        status="ok",
        message="Feishu webhook test sent",
        webhook_url=webhook_url,
    )


# ── Helpers ───────────────────────────────────────────────────────────────────
def _mask(value: str) -> str:
    """Partially mask a secret value for display."""
    if not value or len(value) < 8:
        return value
    return value[:4] + "****" + value[-4:]


def _is_masked(value: str) -> bool:
    return "****" in value
