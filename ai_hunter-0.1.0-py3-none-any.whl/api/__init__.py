"""FastAPI application and routes."""
