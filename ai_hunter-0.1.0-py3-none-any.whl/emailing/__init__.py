"""Email automation foundation modules."""

